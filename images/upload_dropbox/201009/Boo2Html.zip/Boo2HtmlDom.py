#coding=utf-8
from xml.dom import minidom
import sys
import os

class MM2Html:
    '转换MM->Html类'
    def __init__(self):
        self.html = '''<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
''' + cssStr + '''
</style>
</head> '''
        self.level = 0
        self.pos = [0 for x in range(0, 10)]

    def procRoot(self, root):
        '处理root节点'
        for i in root.childNodes:
            if i.nodeName == 'node':
                self.procNode(i)
        self.html += "</body>"

    def procNode(self, node):
        '处理Node节点'
        if node.nodeName == 'node':
            self.level += 1
            #Tltle处理
            if self.isHead(node):
                self.pos[self.level - 1] += 1
                self.html += self.getHead(node.getAttribute("TEXT"))
                for i in node.childNodes:
                    MM2Html.procNode(self, i)
            #文本节点处理
            else:
                self.html += '<pre style="margin-left:%s;">%s</pre>' %(str(20 * self.level) + 'px',node.getAttribute("TEXT"))
            self.pos[self.level: 10] =  [0 for x in range(0, 10)]
            self.level -= 1

    def procNodex(self, node):
        deepth = self.position

    def isHead(self, node):
        '判断是否是标题'
        for i in node.parentNode.childNodes:
            for j in i.childNodes:
                if j.nodeName == 'node':
                    return True
        return False
    def getHead(self, text):
        '获取标题Html格式化后内容'
        titlePrefix = ''
        for i in range(0, self.level):
            titlePrefix += str(self.pos[i]) + '.'
        return "<h%s>%s %s</h%s>" %(self.level, titlePrefix, text, self.level)

def getFiles(type):
    '获取当前目录下某类型文件'
    files = os.listdir(os.getcwd())
    fileList = list()
    for file in files:
        if os.path.splitext(file)[1].lower() == type:
            fileList.append(file)
    return fileList

if __name__ == '__main__':

    cssFileName = 'style.css'
    xmlFileNames = getFiles('.mm')

    try:
        cssStr = open(cssFileName, 'r').read()
    except:
        cssStr = ''

    for xmlFileName in xmlFileNames:
        try:
            xmlFile = open(xmlFileName, "r")
            xmlDoc = minidom.parse(xmlFile)
        except:
            print "Unexpected error:", sys.exc_info()[0]
        root = xmlDoc.getElementsByTagName('node')[0]
        html = open(xmlFileName.split('.')[0] + '.html', 'w')
        mm2Html = MM2Html()
        mm2Html.procRoot(root)
        html.write(mm2Html.html.encode('utf-8'))
        html.close()
